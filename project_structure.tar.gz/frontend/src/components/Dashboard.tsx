import React, { useEffect, useState } from 'react';
import { api, type Package } from '../api/client';
import { Play, Pause, Plus, Download, Activity } from 'lucide-react';

export const Dashboard: React.FC = () => {
    const [packages, setPackages] = useState<Package[]>([]);
    const [newLinks, setNewLinks] = useState('');

    useEffect(() => {
        const fetchData = async () => {
            try {
                const res = await api.get('/downloads');
                setPackages(res.data);
            } catch (err) {
                console.error(err);
            }
        };

        fetchData();
        const interval = setInterval(fetchData, 2000); // Poll every 2s
        return () => clearInterval(interval);
    }, []);

    const handleAddLinks = async () => {
        if (!newLinks) return;
        await api.post('/downloads/links', splitLinks(newLinks));
        setNewLinks('');
        // Immediate refresh
        const res = await api.get('/downloads');
        setPackages(res.data);
    };

    const splitLinks = (text: string) => {
        // Basic splitting by newline or space
        return text.split(/[\n\s]+/).filter(l => l.length > 0);
    }

    const handleStart = async () => await api.post('/downloads/start');
    const handleStop = async () => await api.post('/downloads/stop');

    return (
        <div className="min-h-screen bg-cyber-black text-gray-100 p-8 cyber-grid">
            <header className="flex justify-between items-center mb-8 border-b border-cyber-card pb-4">
                <div className="flex items-center gap-4">
                    {/* Logo placeholder - in real app use the img tag with generated logo */}
                    <div className="w-12 h-12 bg-cyber-card rounded-lg flex items-center justify-center neon-border text-cyber-neon">
                        <Activity />
                    </div>
                    <h1 className="text-3xl font-bold neon-text tracking-tighter">JDownloader<span className="text-cyber-neon">Manager</span></h1>
                </div>
                <div className="flex gap-4">
                    <button onClick={handleStart} className="flex items-center gap-2 px-4 py-2 bg-green-500/10 text-green-400 border border-green-500 rounded hover:bg-green-500/20 transition-all">
                        <Play size={18} /> Start All
                    </button>
                    <button onClick={handleStop} className="flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-400 border border-red-500 rounded hover:bg-red-500/20 transition-all">
                        <Pause size={18} /> Stop All
                    </button>
                </div>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Add Links Panel */}
                <div className="lg:col-span-1 bg-cyber-card p-6 rounded-xl border border-gray-800 shadow-xl">
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><Plus className="text-cyber-neon" /> Add Links</h2>
                    <textarea
                        className="w-full h-32 bg-cyber-dark border border-gray-700 rounded p-3 text-sm focus:border-cyber-neon focus:outline-none transition-colors"
                        placeholder="Paste links here..."
                        value={newLinks}
                        onChange={(e) => setNewLinks(e.target.value)}
                    />
                    <button onClick={handleAddLinks} className="mt-4 w-full py-2 bg-cyber-neon text-cyber-black font-bold rounded hover:bg-cyber-neon/80 transition-all">
                        Add to Queue
                    </button>
                </div>

                {/* Downloads List */}
                <div className="lg:col-span-2 space-y-4">
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><Download className="text-cyber-neon" /> Active Downloads</h2>
                    {packages.map(pkg => (
                        <div key={pkg.uuid} className="bg-cyber-card p-4 rounded-xl border border-gray-800 hover:border-cyber-neon/50 transition-all">
                            <div className="flex justify-between items-center mb-2">
                                <h3 className="font-bold text-lg">{pkg.name}</h3>
                                <span className="text-sm text-gray-400">{(pkg.loaded_bytes / 1024 / 1024).toFixed(1)} MB / {(pkg.total_bytes / 1024 / 1024).toFixed(1)} MB</span>
                            </div>
                            <div className="space-y-2">
                                {pkg.links.map(link => (
                                    <div key={link.uuid} className="flex justify-between items-center text-sm bg-cyber-dark p-2 rounded">
                                        <span className="truncate w-1/2">{link.name}</span>
                                        <div className="flex items-center gap-4">
                                            <span className={`text-xs px-2 py-0.5 rounded ${link.status === 'RUNNING' ? 'bg-green-500/20 text-green-400' : 'bg-gray-700 text-gray-400'}`}>
                                                {link.status}
                                            </span>
                                            <span className="text-gray-500 w-24 text-right">
                                                {link.status === 'RUNNING' ? `${(link.speed / 1024 / 1024).toFixed(1)} MB/s` : '-'}
                                            </span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            {/* Progress Bar */}
                            <div className="mt-3 h-1.5 bg-gray-800 rounded-full overflow-hidden">
                                <div
                                    className="h-full bg-gradient-to-r from-cyber-purple to-cyber-neon relative"
                                    style={{ width: `${(pkg.loaded_bytes / Math.max(pkg.total_bytes, 1)) * 100}%` }}
                                >
                                    <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                                </div>
                            </div>
                        </div>
                    ))}

                    {packages.length === 0 && (
                        <div className="text-center py-12 text-gray-500">
                            No active downloads. Add some links to get started.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
