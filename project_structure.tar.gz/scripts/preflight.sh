#!/bin/bash

# preflight.sh
# Runs local validation to ensure code is ready for push.
# Usage: ./scripts/preflight.sh [fast|full]

MODE=${1:-fast} # Default to fast mode

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}🚀 Starting Pre-Flight Validation ($MODE mode)...${NC}"

FAILED_STEPS=()

# Function to report status
report_status() {
    if [ ${#FAILED_STEPS[@]} -eq 0 ]; then
        echo -e "\n${GREEN}✅ PRE-FLIGHT CHECK PASSED! Ready for takeoff.${NC}"
        exit 0
    else
        echo -e "\n${RED}❌ PRE-FLIGHT CHECK FAILED.${NC}"
        echo "Failed Steps:"
        for step in "${FAILED_STEPS[@]}"; do
            echo -e " - ${step}"
        done
        exit 1
    fi
}

# --- STEP 1: Local Linting (Fast) ---
echo -e "\n${YELLOW}[1/3] Running Local Linters...${NC}"

# Backend Linting
echo "  -> Checking Backend (Ruff)..."
if command -v ruff &> /dev/null; then
    if ! ruff check backend/; then
        echo -e "${RED}     [FAIL] Backend Linting${NC}"
        FAILED_STEPS+=("Backend Lint (Ruff)")
    else
        echo -e "${GREEN}     [PASS] Backend Linting${NC}"
    fi
else
    echo -e "${YELLOW}     [SKIP] Ruff not found (install with 'pip install ruff')${NC}"
fi

# Frontend Linting
echo "  -> Checking Frontend (ESLint/TSC)..."
if [ -d "frontend" ] && command -v npm &> /dev/null; then
    cd frontend
    if ! npm run lint --if-present -- --quiet; then
         echo -e "${RED}     [FAIL] Frontend Linting${NC}"
         FAILED_STEPS+=("Frontend Lint")
    else
         echo -e "${GREEN}     [PASS] Frontend Linting${NC}"
    fi
    cd ..
else
    echo -e "${YELLOW}     [SKIP] Frontend directory or npm not found${NC}"
fi


# --- STEP 2: CI Simulation (Full Mode ONLY) ---
if [ "$MODE" == "full" ]; then
    echo -e "\n${YELLOW}[2/3] Simulating GitHub Actions (using act)...${NC}"
    
    # Check for secrets file
    SECRETS_ARG=""
    if [ -f ".secrets" ]; then
        SECRETS_ARG="--secret-file .secrets"
    elif [ -f ".env" ]; then
         echo -e "${YELLOW}     Note: Using .env for secrets${NC}"
         SECRETS_ARG="--env-file .env"
    fi

    # Run specific job from ci-orchestrator
    # We target 'lint' and 'test' mainly. 'act' runs push events by default unless specified.
    # -j lint,test can be used to run specific jobs, or just let it run the whole workflow.
    # Using -W to point to the file.
    
    echo "  -> Running CI Pipeline..."
    if act -W .github/workflows/ci-orchestrator.yml $SECRETS_ARG --rm; then
        echo -e "${GREEN}     [PASS] CI Simulation${NC}"
    else
        echo -e "${RED}     [FAIL] CI Simulation${NC}"
        FAILED_STEPS+=("GitHub Actions Simulation (act)")
    fi
else
    echo -e "\n${YELLOW}[2/3] Skipping CI Simulation (Use './scripts/preflight.sh full' to run)${NC}"
fi

# --- Final Report ---
report_status
