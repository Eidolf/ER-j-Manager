# JDownloader Manager Backend

FastAPI backend for JDownloader Manager.
